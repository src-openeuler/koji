Koji 1.16.2 Release Notes
=========================

Koji 1.16.2 is a bugfix release for Koji 1.16.
The purpose of this release is address  :doc:`../CVEs/CVE-2018-1002161`.

See also:

- :doc:`release_notes_1.16.1`

- :doc:`release_notes_1.16`


Issues fixed in 1.16.2
----------------------

- `Issue 1183 <https://pagure.io/koji/issue/1183>`_ --
  CVE-2018-1002161
