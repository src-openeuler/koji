Migrating to Koji 1.15
======================

..
  reStructured Text formatted

The update from to 1.15 is comparatively light from a migration perspective.

DB Updates
----------

There are no schema updates in 1.15.


Other changes
-------------

There are numerous other changes in 1.15 that should not have a direct impact
on migration. For details see:
:doc:`../release_notes/release_notes_1.15`
