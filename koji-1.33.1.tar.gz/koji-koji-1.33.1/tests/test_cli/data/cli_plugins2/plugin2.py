from koji.plugin import export_cli


@export_cli
def foo5():
    pass
