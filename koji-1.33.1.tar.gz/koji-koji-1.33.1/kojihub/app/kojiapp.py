from kojihub.kojixmlrpc import application  # noqa: F401
