-- upgrade script to migrate the Koji database schema
-- from version 1.28 to 1.29


-- This version introduced no changes in db schema
