Migrating to Koji 1.27
======================

You should consider the following changes when migrating to 1.27:

DB Updates
----------

This release doesn't include any schema change.

Other changes
-------------

There are numerous other changes in 1.27 that should not have a direct impact on migration. For
details see: :doc:`../release_notes/release_notes_1.27`
