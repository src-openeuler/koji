==========
Migrations
==========

.. toctree::
    :maxdepth: 1

    migrating_to_1.33
    migrating_to_1.32
    migrating_to_1.31
    migrating_to_1.30
    migrating_to_1.29
    migrating_to_1.28
    migrating_to_1.27
    migrating_to_1.26
    migrating_to_1.25
    migrating_to_1.24
    migrating_to_1.23
    migrating_to_1.22
    migrating_to_1.21
    migrating_to_1.20
    migrating_to_1.19
    migrating_to_1.18
    migrating_to_1.17
    migrating_to_1.16
    migrating_to_1.15
    migrating_to_1.14
    migrating_to_1.13
    migrating_to_1.12
    migrating_to_1.11
    migrating_to_1.10
    migrating_to_1.9
    migrating_to_1.8
    migrating_to_1.7
