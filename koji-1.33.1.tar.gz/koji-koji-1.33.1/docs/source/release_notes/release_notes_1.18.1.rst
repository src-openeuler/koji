Koji 1.18.1 Release Notes
=========================

Koji 1.18.1 is a bugfix release for Koji 1.18.
The purpose of this release is address  :doc:`../CVEs/CVE-2019-17109`.


Issues fixed in 1.18.1
----------------------

- `Issue 1634 <https://pagure.io/koji/issue/1634>`_ --
  possible to upload file to a path other than work directory
